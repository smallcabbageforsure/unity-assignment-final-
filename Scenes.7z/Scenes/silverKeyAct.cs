using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;

public class silverKeyAct : MonoBehaviour
{
    [Header("Key Settings")]
    [SerializeField] private string keyColor = "silver";

    private UnityEngine.XR.Interaction.Toolkit.Interactables.XRGrabInteractable grabInteractable;
    private bool isCollected = false;

    void Start()
    {
        grabInteractable = GetComponent<UnityEngine.XR.Interaction.Toolkit.Interactables.XRGrabInteractable>();

        if (grabInteractable != null)
        {
            grabInteractable.selectEntered.AddListener(OnGrabbed);
        }
    }

    private void OnGrabbed(SelectEnterEventArgs args)
    {
        if (isCollected) return;
        isCollected = true;

        Debug.Log("Key collected: " + keyColor);

        // Find the player key manager
        PlayerKeyManager keyManager = FindObjectOfType<PlayerKeyManager>();

        if (keyManager != null)
        {
            keyManager.AddKey(keyColor);
        }

        // Force release the key from the hand
        if (grabInteractable != null)
        {
            var interactor = args.interactorObject;
            if (interactor is UnityEngine.XR.Interaction.Toolkit.Interactors.IXRSelectInteractor selectInteractor)
            {
                grabInteractable.interactionManager.SelectExit(selectInteractor, grabInteractable);
            }
        }

        // Make key disappear completely
        Destroy(gameObject);
    }
}
