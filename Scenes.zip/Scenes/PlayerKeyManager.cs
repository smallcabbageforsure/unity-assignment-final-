using UnityEngine;
using System.Collections.Generic;

public class PlayerKeyManager : MonoBehaviour
{
    private List<string> collectedKeys = new List<string>();

    public void AddKey(string keyColor)
    {
        if (!collectedKeys.Contains(keyColor))
        {
            collectedKeys.Add(keyColor);
            Debug.Log("Collected " + keyColor + " key! Total keys: " + collectedKeys.Count);

            // Debug: Show all collected keys
            Debug.Log("All keys: " + string.Join(", ", collectedKeys));
        }
    }

    public bool HasKey(string keyColor)
    {
        bool hasKey = collectedKeys.Contains(keyColor);
        Debug.Log("Checking for key '" + keyColor + "': " + hasKey);
        return hasKey;
    }
}