using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using TMPro;

public class DoorTutorAct : MonoBehaviour
{
    [Header("Door Settings")]
    [SerializeField] private string requiredKeyColor = "Blue";
    [SerializeField] private float openAngle = 90f;
    [SerializeField] private float openSpeed = 2f;

    [Header("Text Display")]
    [SerializeField] private TextMeshPro displayTextdoorTutor;
    [SerializeField] private float displayTime = 3f;

    private bool isOpen = false;
    private bool isOpening = false;
    private Vector3 closedRotation;
    private Vector3 openRotation;
    private UnityEngine.XR.Interaction.Toolkit.Interactables.XRGrabInteractable grabInteractable;
    private float hideTextTime = 0f;

    void Start()
    {
        // Store the current rotation
        closedRotation = transform.eulerAngles;
        openRotation = new Vector3(closedRotation.x, closedRotation.y + openAngle, closedRotation.z);

        // Add XR Grab Interactable component
        grabInteractable = GetComponent<UnityEngine.XR.Interaction.Toolkit.Interactables.XRGrabInteractable>();
        if (grabInteractable == null)
        {
            grabInteractable = gameObject.AddComponent<UnityEngine.XR.Interaction.Toolkit.Interactables.XRGrabInteractable>();
        }

        // Make door physics proper
        Rigidbody rb = GetComponent<Rigidbody>();
        if (rb == null)
        {
            rb = gameObject.AddComponent<Rigidbody>();
        }
        rb.isKinematic = true;

        // Configure grab settings
        grabInteractable.trackPosition = false;
        grabInteractable.trackRotation = false;
        grabInteractable.throwOnDetach = false;

        // Listen for interaction
        grabInteractable.selectEntered.AddListener(OnDoorInteracted);

        // Hide text at start
        if (displayTextdoorTutor != null)
        {
            displayTextdoorTutor.gameObject.SetActive(false);
        }
    }

    void Update()
    {
        if (isOpening)
        {
            // Smoothly rotate to the open position
            transform.rotation = Quaternion.Lerp(transform.rotation, Quaternion.Euler(openRotation), openSpeed * Time.deltaTime);

            // Check if we're close enough to the target rotation
            if (Quaternion.Angle(transform.rotation, Quaternion.Euler(openRotation)) < 1f)
            {
                isOpening = false;
                isOpen = true;
            }
        }

        // Hide text after display time
        if (displayTextdoorTutor != null && displayTextdoorTutor.gameObject.activeInHierarchy && Time.time > hideTextTime)
        {
            displayTextdoorTutor.gameObject.SetActive(false);
        }
    }

    private void OnDoorInteracted(SelectEnterEventArgs args)
    {
        if (isOpen || isOpening) return;

        PlayerKeyManager keyManager = FindObjectOfType<PlayerKeyManager>();
        if (keyManager != null && keyManager.HasKey(requiredKeyColor))
        {
            OpenDoor();
        }
        else
        {
            ShowNeedKeyMessage();
        }
    }

    private void OpenDoor()
    {
        isOpening = true;

        // Hide text if it's showing
        if (displayTextdoorTutor != null)
        {
            displayTextdoorTutor.gameObject.SetActive(false);
        }

        // Disable further interaction
        if (grabInteractable != null)
        {
            grabInteractable.enabled = false;
        }
    }

    private void ShowNeedKeyMessage()
    {
        if (displayTextdoorTutor != null)
        {
            // Show the text for 3 seconds
            displayTextdoorTutor.gameObject.SetActive(true);
            hideTextTime = Time.time + displayTime;
        }
    }
}